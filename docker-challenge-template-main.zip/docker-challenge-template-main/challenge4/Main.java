import java.io.*;
import com.sun.net.httpserver.*;

public class Main {

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new java.net.InetSocketAddress(8080), 0);
        server.createContext("/api/books", new BooksHandler());
        server.createContext("/api/books/1", new BookByIdHandler());
        server.createContext("/api/stats", new StatsHandler()); // Register handler for /api/stats
        server.start();
    }

    static class BooksHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String response = "All books";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class BookByIdHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String response = "Book with id 1";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class StatsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String response = "Stats endpoint";
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }
}
